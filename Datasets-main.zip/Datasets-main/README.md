# clase1
para clase 1 


[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/tec03/Datasets/main)

.. image:: https://mybinder.org/badge_logo.svg
 :target: https://mybinder.org/v2/gh/tec03/Datasets/main
